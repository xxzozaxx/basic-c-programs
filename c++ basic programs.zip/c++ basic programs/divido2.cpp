#include <iostream>
using namespace std;
int main()
{

long dividend,divisor;
char ch;
do {

	cout <<"enter dividend";cin >>dividend;
	cout <<"enter divisor";cin >>divisor;
	if (divisor==0){
		cout<<"iilegal divisor\n";
		continue;
	}
cout <<endl<<"quantient is"<<dividend/divisor;
cout <<endl<<"remainder is" <<dividend%divisor;
cout <<"\n Do another? (y/n):";
cin >>ch;

}
while (ch !='n');

return 0;
}
