#include <iostream>
using namespace std ;
int main()
{

float f,F;
cout<< "inter Fahrenheit degree";
cin>>f;
F=5/9*(f-32);
cout<< F;
return 0;




}
