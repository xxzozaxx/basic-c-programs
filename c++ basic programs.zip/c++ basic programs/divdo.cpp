#include <iostream>
using namespace std;
int main()
{
long x,y;
char ch;
do {
    cout<<"inter x";
    cin>>x;
    cout<<"inter y";
    cin>> y;
    cout<<"division is"<<x/y<<endl;
    cout<<"remendir is"<<x%y<<endl;
    cout <<"nDo another? (y/n):";
    cin>> ch;
}
 while (ch!='n');
return 0;

}




