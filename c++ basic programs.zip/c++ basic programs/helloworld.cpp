#include <iostream>
using namespace std;
int main()
{
  float x,y;
    cout<<"please input your first number " ;
cin>>x;
cout<<"input your second numbre";
cin>>y;
cout<<x*y;
return 0;
}
