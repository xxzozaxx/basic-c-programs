#include <iostream>
#include <cmath>
using namespace std;
int main()
{

float a,b;
cout<<"inter the number\n";
cin>>a;
b=sqrt(a);
cout <<"the square root is="<<b<<endl;

return 0;
}