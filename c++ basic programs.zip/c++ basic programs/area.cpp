#include <iostream> 
using namespace std;  
int main() 
{ 
float length, width, area; 
cout << "Enter the length of the rectangle: "; 
cin >> length; 
cout << "Now enter the width: "; 
cin >> width; 
area = length*width; 
cout <<"The area of the rectangle is: "<< area << endl;
return 0; 
} 
