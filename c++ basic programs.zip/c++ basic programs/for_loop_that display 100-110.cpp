#include <iostream>
using namespace std;
int main()
{
for (int j=100;j<=110;j++)
cout<<endl<<j;



return 0;
}

