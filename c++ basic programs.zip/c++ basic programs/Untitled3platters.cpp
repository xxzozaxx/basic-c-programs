#include <iostream>
using namespace std;
int main()
{
int speed;
cout<<"\nenter33,45,or78:";
cin>>speed;
if (speed != 33&&45&&78)
        cout <<"error number";
switch (speed)
{
case 33:
    cout<<"lpalbum\n";
    break;
    case 45:
    cout <<"single selection \n";
    break;
    case 78:
    cout<<"obsolute format\n";
    break;

}
return 0;
}
