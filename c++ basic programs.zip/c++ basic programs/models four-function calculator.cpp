#include <iostream>
using namespace std;
int main()
{
double n1,n2,ans;
char oper,ch;
do{
    cout<< "enter first number"<<endl;
    cin >> n1;
    cout <<"enter second number";
    cin >> n2;
    cout <<"enter operator "<<endl;
    cin >> oper;
    switch(oper){
    case '+' : ans= n1 + n2 ; break;
    case '-' : ans= n1 - n2 ; break;
    case '/' : ans= n1 / n2 ; break;
    case '*' : ans= n1 * n2 ; break;
    default : ans=0;}
cout << "Answer is" <<ans;
cout <<endl<< "do yo know another (Enter'y' or 'n')?";
cin >> ch;
}
while (ch!='n');

return 0;
}
