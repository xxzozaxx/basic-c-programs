#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
int x,cube;
for (x=1;x<10;x++)
{
    cout<<setw(1)<<x;
    cube =x*x*x;
    cout<<setw(20)<<cube<<endl;
}



return 0;
}
