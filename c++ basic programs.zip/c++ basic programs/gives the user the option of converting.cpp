// this is by angel_ace Eng:Ahmed_Salah
#include <iostream>
using namespace std;
int main()
{
    int response,temper;
cout <<"Type 1 to convert fahrenheit to celsius"<< "2 to convert celsius to fahrenheit";
cin >> response;

if( response == 1 )
{
cout << "Enter temperature in fahrenheit: ";
cin >> temper;
cout << "In celsius that’s " << 5.0/9.0*(temper-32.0);
}
else
{
cout << "Enter temperature in celsius: ";
cin >> temper;
cout << "In fahrenheit that’s " << 9.0/5.0*temper + 32.0;
}
cout << endl;
return 0;
}

