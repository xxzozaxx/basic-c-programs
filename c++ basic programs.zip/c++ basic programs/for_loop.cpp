#include <iostream>
using namespace std;
int main()
{
int x;
for (x=0;x<15;x++)
    cout<<x*x<<""<<endl;

return 0;
}
