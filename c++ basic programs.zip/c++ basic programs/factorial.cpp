// this is by angel ace  Eng_Ahmed_salah
#include <iostream>
using namespace std;
int main()
{
int f=1,x;
char ch;
cout <<"inter the number"<<endl;
cin>>x;
while ( x>=1)
    {
        f=f*x;
        x--;
    }
        cout<<endl<<f;
        /*cout <<endl<< "do you want another (Enter 'y' or 'n')? ";
        cin>> ch;
        while (ch != 'n');*/
return 0;
}
