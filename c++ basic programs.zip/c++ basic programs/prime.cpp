#include <iostream>
using namespace std;
int main()
{
unsigned long x,y;
cout<<"inter anumber";
cin>>x;
for (y=2;y<=x/2;y++)
    if(x%y==0){
cout <<"\nit is prime:"<<y<<endl;
exit(0);
    }
cout << "It’s prime";

return 0;
}
