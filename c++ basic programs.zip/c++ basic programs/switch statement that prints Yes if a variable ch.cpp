#include <iostream>
using namespace std;
int main()
{

switch(ch)
{
case ‘y’:
cout << “Yes”;
break;
case ‘n’:
cout << “No”;
break;
default:
cout << “Unknown response”;
}



return 0;
}

