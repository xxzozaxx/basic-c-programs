// calculates factorials, demonstrates FOR loop
#include <iostream>
using namespace std;
int main()
{
int numb;
long fact=1;
cout << “Enter a number “;
cin >> numb;
//long for larger numbers
//get numberLoops and Decisions
85
for(int j=numb; j>0; j--)
//multiply 1 by
fact *= j;
//numb, numb-1, ..., 2, 1
cout << “Factorial is “ << fact << endl;
return 0;
}
