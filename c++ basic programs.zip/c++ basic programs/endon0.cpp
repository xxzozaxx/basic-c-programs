#include <iostream>
using namespace std;
int main()
{
int n = 99;
while( n != 0 )
cin >> n;
cout << n<<endl;
return 0;
}
