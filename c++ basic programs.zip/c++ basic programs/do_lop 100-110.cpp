#include <iostream>
using namespace std;
int main()
{

int j=100;
do
    cout <<endl<<j++;
while (j<=110);


return 0;
}

